from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'retries': 1,
    'retry_delay': timedelta(minutes=2)
}

with DAG(
    dag_id='weather_etl_pipeline',
    default_args=default_args,
    description='Fetch and transform weather data every hour',
    start_date=datetime(2023, 1, 1),
    schedule_interval='@hourly',
    catchup=False
) as dag:

    fetch_weather = BashOperator(
        task_id='fetch_weather_data',
        bash_command='python3 /opt/airflow/producer/fetch_weather_data.py'
    )

    transform_data = BashOperator(
        task_id='transform_weather_data',
        bash_command='spark-submit /opt/airflow/spark/transform_weather_data.py'
    )

    fetch_weather >> transform_data
