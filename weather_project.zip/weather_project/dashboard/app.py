import os
import pandas as pd
import streamlit as st

DATA_DIR = "data"

st.title("📊 Weather Data Dashboard")

def load_all_csvs(base_dir):
    all_dfs = []
    for folder in sorted(os.listdir(base_dir)):
        folder_path = os.path.join(base_dir, folder)
        if os.path.isdir(folder_path):
            for f in os.listdir(folder_path):
                if f.endswith(".csv"):
                    csv_path = os.path.join(folder_path, f)
                    try:
                        df = pd.read_csv(csv_path)
                        all_dfs.append(df)
                    except Exception as e:
                        st.warning(f"⚠️ Failed to load {csv_path}: {e}")
    if all_dfs:
        return pd.concat(all_dfs, ignore_index=True)
    return pd.DataFrame()

if not os.path.exists(DATA_DIR):
    st.error(f"❌ Data directory not found: {DATA_DIR}")
elif not os.listdir(DATA_DIR):
    st.warning("⚠️ Data folder is empty.")
else:
    df = load_all_csvs(DATA_DIR)

    if df.empty:
        st.warning("⚠️ No data available to display.")
    else:
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        numeric_cols = ["temp_c", "humidity", "wind_kph", "uv", "air_quality"]
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')

        df = df.sort_values("timestamp")

        st.success(f"✅ Loaded {len(df)} records")
        st.dataframe(df.tail())

        st.subheader("📌 Choose Parameters to Visualize")
        options = st.multiselect(
            "Select weather features to visualize:",
            options=numeric_cols,
            default=["temp_c"]
        )

        if options:
            for col in options:
                st.subheader(f"{col.replace('_', ' ').title()} Over Time")
                st.line_chart(df.set_index("timestamp")[col])
        else:
            st.info("👈 Select at least one parameter to visualize.")
