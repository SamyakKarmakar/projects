import requests
import json
import os
import pandas as pd
import sys
from datetime import datetime

# Replace this with your own WeatherAPI key
API_KEY = "585f068398ad4ef7a51130215251407"
CITY = sys.argv[1] if len(sys.argv) > 1 else "Kolkata"
URL = f"http://api.weatherapi.com/v1/current.json?key={API_KEY}&q={CITY}&aqi=yes"

# Create directory if not exists
os.makedirs("/opt/airflow/data/raw_data", exist_ok=True)

try:
    response = requests.get(URL)
    data = response.json()

    if "current" not in data:
        print("❌ Error in API response:", data)
        exit()

    # Extract required fields
    current = data["current"]
    location = data["location"]

    record = {
        "timestamp": datetime.now().isoformat(),
        "city": location["name"],
        "region": location["region"],
        "country": location["country"],
        "temp_c": current["temp_c"],
        "humidity": current["humidity"],
        "wind_kph": current["wind_kph"],
        "condition": current["condition"]["text"],
        "uv": current["uv"],
        "air_quality": current.get("air_quality", {}).get("pm2_5", None),
    }

    df = pd.DataFrame([record])

    # Save to CSV with timestamped filename
    filename = f"weather_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    df.to_csv(f"/opt/airflow/data/raw_data/{filename}", index=False)
    print(f"✅ Weather data saved to: {filename}")

except Exception as e:
    print("❌ Failed to fetch weather data:", e)
