import requests
import json
import os
import pandas as pd
import sys
from datetime import datetime

API_KEY = "YOUR_API_KEY"
CITY = sys.argv[1] if len(sys.argv) > 1 else "YOUR_DESIRED_CITY"
URL = f"http://api.weatherapi.com/v1/current.json?key={API_KEY}&q={CITY}&aqi=yes"

os.makedirs("/opt/airflow/data/raw_data", exist_ok=True)

try:
    response = requests.get(URL)
    data = response.json()

    if "current" not in data:
        print("❌ Error in API response:", data)
        exit()


    current = data["current"]
    location = data["location"]

    record = {
        "timestamp": datetime.now().isoformat(),
        "city": location["name"],
        "region": location["region"],
        "country": location["country"],
        "temp_c": current["temp_c"],
        "humidity": current["humidity"],
        "wind_kph": current["wind_kph"],
        "condition": current["condition"]["text"],
        "uv": current["uv"],
        "air_quality": current.get("air_quality", {}).get("pm2_5", None),
    }

    df = pd.DataFrame([record])


    filename = f"weather_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    df.to_csv(f"/opt/airflow/data/raw_data/{filename}", index=False)
    print(f"✅ Weather data saved to: {filename}")

except Exception as e:
    print("❌ Failed to fetch weather data:", e)
