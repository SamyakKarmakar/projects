from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit
import os
import sys

try:
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("WeatherDataTransformation") \
        .getOrCreate()

    RAW_DATA_PATH = "/opt/airflow/data/raw_data"
    TRANSFORMED_DATA_PATH = "/opt/airflow/data/transformed_data"

    # Get the latest raw data file
    files = [f for f in os.listdir(RAW_DATA_PATH) if f.endswith(".csv")]
    if not files:
        print("❌ No raw data files found.")
        sys.exit(1)

    latest_file = sorted(files)[-1]
    input_path = os.path.join(RAW_DATA_PATH, latest_file)

    # Read raw data
    df = spark.read.option("header", True).csv(input_path)

    # Transformations
    df = df.withColumn("temp_c", col("temp_c").cast("float")) \
           .withColumn("humidity", col("humidity").cast("int")) \
           .withColumn("wind_kph", col("wind_kph").cast("float")) \
           .withColumn("uv", col("uv").cast("float")) \
           .withColumn("air_quality", col("air_quality").cast("float")) \
           .withColumn("processed_at", lit(df.select("timestamp").first()[0]))

    # Save transformed data
    os.makedirs(TRANSFORMED_DATA_PATH, exist_ok=True)
    output_file = f"{TRANSFORMED_DATA_PATH}/transformed_{latest_file}"
    df.write.mode("overwrite").option("header", True).csv(output_file)

    print(f"✅ Transformed data saved to: {output_file}")

except Exception as e:
    print(f"❌ Error during transformation: {e}")
    sys.exit(1)

finally:
    spark.stop()
