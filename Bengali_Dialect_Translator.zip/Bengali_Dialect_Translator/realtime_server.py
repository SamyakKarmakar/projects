from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from s2s_inference_hybrid import run_end_to_end 

app = FastAPI(title="Bangla Dialect Translator Hybrid API")

# Simple HTML for testing the WebSocket connection (Client-side code)
html = """
<!DOCTYPE html>
<html>
    <head>
        <title>Dialect Translator</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Real-Time Dialect Translator</h1>
        <p>Status: <span id="status">Disconnected</span></p>
        <p>Last Dialect Spoken: <span id="dialect_text"></span></p>
        <button onclick="startListening()">Start Translation</button>
        <button onclick="stopListening()" disabled>Stop Translation</button>
        <audio id="audioPlayback" controls style="display:none;"></audio>
        
        <script>
            // --- Audio Configuration ---
            const SAMPLE_RATE = 16000; 
            const BUFFER_SIZE = 4096;
            
            let ws;
            let audioContext;
            let mediaStreamSource;
            let recorder;
            let audioQueue = [];
            let isPlaying = false;

            function log(message) {
                document.getElementById('status').textContent = message;
            }

            function updateDialect(text) {
                document.getElementById('dialect_text').textContent = text;
            }

            // Function to play audio from the queue
            async function playNextChunk() {
                if (audioQueue.length > 0 && !isPlaying) {
                    isPlaying = true;
                    const audioBlob = audioQueue.shift();
                    const audioUrl = URL.createObjectURL(audioBlob);
                    const audio = document.getElementById('audioPlayback');
                    
                    audio.src = audioUrl;
                    
                    // Decode audio data to extract the recognized text (if included in the header/metadata)
                    // For this basic setup, we'll just play the sound.
                    
                    await audio.play().catch(e => console.error("Audio playback error:", e));
                    
                    audio.onended = () => {
                        URL.revokeObjectURL(audioUrl);
                        isPlaying = false;
                        playNextChunk(); // Play the next chunk in the queue
                    };
                }
            }
            
            function startListening() {
                log('Connecting...');
                ws = new WebSocket("ws://localhost:8000/ws/translate");

                ws.onopen = () => {
                    log("Connected. Streaming audio...");
                    navigator.mediaDevices.getUserMedia({ audio: { sampleRate: SAMPLE_RATE } })
                        .then(stream => {
                            audioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: SAMPLE_RATE });
                            mediaStreamSource = audioContext.createMediaStreamSource(stream);

                            // Setup audio processor
                            // Note: ScriptProcessorNode is deprecated, but widely supported for simple testing.
                            recorder = audioContext.createScriptProcessor(BUFFER_SIZE, 1, 1);
                            
                            recorder.onaudioprocess = (e) => {
                                const inputData = e.inputBuffer.getChannelData(0);
                                const int16Array = convertFloat32ToInt16(inputData);
                                
                                if (ws.readyState === WebSocket.OPEN) {
                                    ws.send(int16Array.buffer);
                                }
                            };

                            mediaStreamSource.connect(recorder);
                            recorder.connect(audioContext.destination);

                            document.querySelector('button[onclick="startListening()"]').disabled = true;
                            document.querySelector('button[onclick="stopListening()"]').disabled = false;
                        })
                        .catch(err => {
                            log(`Microphone Error: ${err.name}. Check permissions.`);
                            ws.close();
                        });
                };

                ws.onmessage = (event) => {
                    if (event.data instanceof Blob) {
                        // Queue the incoming translated audio
                        audioQueue.push(event.data);
                        playNextChunk(); 
                    } 
                    // Add logic here to receive ASR text if you modify the server to send text too
                };

                ws.onclose = () => {
                    log("Connection closed.");
                    document.querySelector('button[onclick="startListening()"]').disabled = false;
                    document.querySelector('button[onclick="stopListening()"]').disabled = true;
                };

                ws.onerror = (error) => {
                    log(`WebSocket Error: ${error.message}`);
                };
            }

            function stopListening() {
                if (ws) ws.close();
                if (mediaStreamSource) mediaStreamSource.mediaStream.getTracks().forEach(track => track.stop());
                if (audioContext) audioContext.close();
                log('Stopped. Connection closed.');
            }
            
            // Utility function to convert Float32Array to 16-bit PCM Int16Array
            function convertFloat32ToInt16(buffer) {
                let l = buffer.length;
                let buf = new Int16Array(l);
                while (l--) {
                    buf[l] = Math.min(1, buffer[l]) * 0x7FFF;
                }
                return buf;
            }
        </script>
    </body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def get():
    return html

@app.websocket("/ws/translate")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for real-time audio streaming and translation.
    """
    await websocket.accept()
    print("WebSocket connected.")
    try:
        while True:
            # Receive audio chunk (bytes) from the client
            audio_chunk = await websocket.receive_bytes()
            
            # 1. Process the chunk through the S2S hybrid pipeline
            translated_audio_bytes = run_end_to_end(audio_chunk)
            
            # 2. Stream the translated audio back to the client
            if translated_audio_bytes:
                await websocket.send_bytes(translated_audio_bytes)
                
    except Exception as e:
        print(f"WebSocket closed or error occurred: {e}")
    finally:
        await websocket.close()
        print("WebSocket disconnected.")

# To run the server:
# uvicorn realtime_server:app --reload