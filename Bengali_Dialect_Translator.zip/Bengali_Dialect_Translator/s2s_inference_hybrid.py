import torch
from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
import numpy as np
import io
import torchaudio
import soundfile as sf
from normalizer import DialectNormalizer # Import your custom normalizer

# --- CONFIGURATION (UPDATE THESE PATHS) ---
ASR_MODEL_PATH = "openai/whisper-small"  # Fine-tuned for Bangla dialects if possible
TTS_MODEL_PATH = "TTS_Model_Checkpoint"  # Placeholder for a Bangla TTS model (e.g., from AI4Bharat)

# Initialize Device
device = "cuda:0" if torch.cuda.is_available() else "cpu"

# ----------------------------------------------------------------------
# 1. LOAD MODELS
# ----------------------------------------------------------------------

# ASR Model (Dialect Speech -> Text)
try:
    asr_pipeline = pipeline(
        "automatic-speech-recognition",
        model=ASR_MODEL_PATH,
        device=device,
        chunk_length_s=30, 
    )
except Exception as e:
    print(f"ASR Model loading failed (using mock): {e}")
    asr_pipeline = None

# Normalizer (Dialect Text -> Standard-like Text)
try:
    normalizer = DialectNormalizer(dict_path='dialect_normalization_rules.json')
except Exception as e:
    print(f"Normalizer initialization failed: {e}")
    normalizer = None

# ----------------------------------------------------------------------
# 2. CORE FUNCTIONS
# ----------------------------------------------------------------------

def run_asr(audio_chunk: bytes) -> str:
    """Converts a raw audio chunk (bytes) to dialect text."""
    if not asr_pipeline:
        return "ছেলেডা আইজকে কি করতাছস?" # Mock ASR output

    try:
        # Load audio data from bytes (assuming client sends WAV/PCM data)
        audio_input, sample_rate = torchaudio.load(io.BytesIO(audio_chunk))
        # Resample to 16000 Hz if needed by Whisper
        if sample_rate != 16000:
            resampler = torchaudio.transforms.Resample(sample_rate, 16000)
            audio_input = resampler(audio_input)

        # Transcribe
        result = asr_pipeline(audio_input.squeeze().numpy(), sampling_rate=16000)
        return result['text'].strip()

    except Exception as e:
        print(f"ASR error: {e}")
        return "" # Return empty if ASR fails


def run_tts(standard_text: str) -> bytes:
    """Converts Standard Bangla text to Standard Bangla audio (bytes)."""
    # NOTE: This function needs a full TTS model (e.g., FastPitch/HiFi-GAN for Bangla).
    # We are using a mock silent audio for structural integrity.
    print(f"TTS generating speech for: '{standard_text}'")
    
    sample_rate = 16000
    duration_seconds = 1.0 # Simulate processing time
    num_samples = int(duration_seconds * sample_rate)
    mock_audio = np.zeros(num_samples, dtype=np.float32)

    # Convert the numpy array to WAV bytes
    with io.BytesIO() as wav_io:
        sf.write(wav_io, mock_audio, sample_rate, format='wav')
        wav_bytes = wav_io.getvalue()
    
    return wav_bytes


def run_end_to_end(audio_chunk: bytes) -> bytes:
    """The full S2S pipeline: Speech -> ASR -> Normalizer -> TTS."""
    
    # 1. ASR (Speech -> Dialect Text)
    dialect_text = run_asr(audio_chunk)
    
    if not dialect_text or len(dialect_text.split()) < 2:
        return b'' # Ignore short or empty inputs

    # 2. Normalizer (Dialect Text -> Standard-like Text)
    if normalizer:
        standard_text = normalizer.normalize(dialect_text)
    else:
        standard_text = dialect_text
        
    print(f"Dialect: '{dialect_text}' | Standard: '{standard_text}'")

    # 3. TTS (Standard Bangla Text -> Standard Bangla Speech)
    standard_audio_bytes = run_tts(standard_text)
    
    return standard_audio_bytes

if __name__ == "__main__":
    # Test normalization logic before starting the server
    test_sentence = "যেহেতু তুমি চেষ্টা হরো নাই তাই ব্যর্থ হইছো।"
    normalized = normalizer.normalize(test_sentence)
    print(f"Test Sentence: {test_sentence}")
    print(f"Normalized Output: {normalized}")