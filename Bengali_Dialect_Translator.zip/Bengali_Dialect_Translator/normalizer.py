import json
import re

class DialectNormalizer:
    """
    A rule-based normalizer that converts dialectal words/phrases to their 
    Standard Bangla equivalents using a substitution dictionary.
    """
    def __init__(self, dict_path='dialect_normalization_rules.json'):
        self.rules = self._load_rules(dict_path)
        # Create a combined regex pattern for fast replacement
        # Sort keys by length (longest first) to prevent partial matching (e.g., 'কইতাছস' before 'কইতা')
        self.sorted_dialect_terms = sorted(self.rules.keys(), key=len, reverse=True)
        self.pattern = re.compile(r'|'.join(re.escape(term) for term in self.sorted_dialect_terms))
        
    def _load_rules(self, dict_path):
        """Loads the manually created substitution rules."""
        try:
            with open(dict_path, 'r', encoding='utf-8') as f:
                rules = json.load(f)
                # Filter out rules where the replacement is empty (i.e., not yet translated)
                return {k: v for k, v in rules.items() if v}
        except FileNotFoundError:
            print(f"Warning: Normalization dictionary not found at {dict_path}. Using empty rules.")
            return {}

    def normalize(self, dialect_sentence: str) -> str:
        """
        Applies substitution rules to the sentence.
        Uses a regex substitution for efficiency.
        """
        if not self.rules:
            return dialect_sentence

        def replace_match(match):
            """Callback function for re.sub to find the replacement."""
            return self.rules.get(match.group(0), match.group(0))

        # Perform the replacement on the sentence
        # Ensure we are working with the lowercased sentence for consistent matching
        normalized_sentence = self.pattern.sub(replace_match, dialect_sentence.lower())
        
        # A simple hack to re-capitalize the first letter, as normalization rules are lowercased
        if normalized_sentence:
            return normalized_sentence[0].upper() + normalized_sentence[1:]
        return normalized_sentence

# Example Usage (after manual editing of the JSON file)
if __name__ == "__main__":
    # Create a mock dictionary for testing the logic
    mock_rules = {
        "ছেলেডা": "ছেলেটি",
        "কইতাছস": "করছো",
        "লাইগ্গা": "জন্য",
        "হেরা": "তারা"
    }
    with open('mock_rules.json', 'w', encoding='utf-8') as f:
        json.dump(mock_rules, f, ensure_ascii=False, indent=4)

    normalizer = DialectNormalizer(dict_path='mock_rules.json')
    test_sentence = "ছেলেডা আজকাইল কি করতাছস? হেরা কিসের লাইগ্গা আসলো?"
    
    normalized = normalizer.normalize(test_sentence)
    
    print(f"Original: {test_sentence}")
    print(f"Normalized: {normalized}")