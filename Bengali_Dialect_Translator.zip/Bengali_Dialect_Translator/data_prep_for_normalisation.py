import pandas as pd
import re
import json

# --- CONFIGURATION ---
FILE_PATH = 'data\BanglaDial.csv'
NORMALIZATION_DICT_PATH = 'dialect_normalization_rules.json'

def prepare_normalization_data(file_path):
    """
    Loads the dialect data and extracts sentences to help identify dialectal terms.
    NOTE: The 'Standard_Mapping' must be filled manually by a linguist.
    """
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return

    # Filter out the standard sentences to focus on dialects
    dialect_df = df[df['Language'] != 'Standard_Bangla'].copy()
    
    # 1. Identify unique dialectal terms (simple tokenization)
    all_dialect_sentences = " ".join(dialect_df['Sentence'].astype(str).tolist())
    # Clean and split into words (removes punctuation, etc.)
    words = re.findall(r'\b\w+\b', all_dialect_sentences.lower())
    unique_dialect_words = sorted(list(set(words)))

    # 2. Create the required structure for manual mapping
    # This dictionary will be the basis of the Normalizer class.
    normalization_map_structure = {
        word: ""  # Empty string is the placeholder for the Standard Bengali equivalent
        for word in unique_dialect_words
    }

    print("--- 🛠️ MANUAL TRANSLATION REQUIRED 🛠️ ---")
    print("The following dictionary structure needs to be manually filled with the Standard Bangla equivalent.")
    print("Example: 'ছেলেডা' -> 'ছেলেটি', 'হের' -> 'তার'")

    # Print a sample of the structure (top 20 unique words for review)
    sample_map = {k: v for i, (k, v) in enumerate(normalization_map_structure.items()) if i < 20}
    
    print("\n--- SAMPLE NORMALIZATION STRUCTURE ---")
    print(json.dumps(sample_map, ensure_ascii=False, indent=4))
    
    # Save the full structure to a file for manual editing
    with open(NORMALIZATION_DICT_PATH, 'w', encoding='utf-8') as f:
        json.dump(normalization_map_structure, f, ensure_ascii=False, indent=4)
        
    print(f"\nSaved full dictionary structure to '{NORMALIZATION_DICT_PATH}' for manual editing.")

if __name__ == "__main__":
    prepare_normalization_data(FILE_PATH)