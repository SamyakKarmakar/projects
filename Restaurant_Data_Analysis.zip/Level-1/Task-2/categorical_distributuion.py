import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

categorical_cols = ['Country Code', 'City', 'Cuisines']

for col in categorical_cols:
    print(f"\nColumn: {col}")
    print(f"Unique values: {df[col].nunique()}")
    print(f"Top 10 frequent values:\n{df[col].value_counts().head(10)}")

    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, y=col, order=df[col].value_counts().index[:10])
    plt.title(f"Top 10 frequent categories in {col}")
    plt.xlabel('Count')
    plt.ylabel(col)
    plt.tight_layout()
    plt.show()
