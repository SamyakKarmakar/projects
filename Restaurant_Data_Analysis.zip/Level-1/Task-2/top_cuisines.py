import pandas as pd

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

top_cuisines = df['Cuisines'].value_counts().head(10)
print("Top 10 Cuisines with highest number of restaurants:")
print(top_cuisines)

print("\n" + "="*40 + "\n")

top_cities = df['City'].value_counts().head(10)
print("Top 10 Cities with highest number of restaurants:")
print(top_cities)
