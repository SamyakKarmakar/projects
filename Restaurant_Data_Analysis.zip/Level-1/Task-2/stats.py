import pandas as pd

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")  
numeric_cols = df.select_dtypes(include=['number']).columns
exclude_cols = ['Restaurant ID']

numeric_cols = [col for col in numeric_cols if col not in exclude_cols]
stats_df = pd.DataFrame(columns=['Mean', 'Median', 'Mode', 'Variance', 'Std Dev', 'Range'])

for col in numeric_cols:
    mean = df[col].mean()
    median = df[col].median()
    mode = df[col].mode()
    mode_list = mode.tolist() if not mode.empty else []
    variance = df[col].var(ddof=0)   
    std_dev = df[col].std(ddof=0)    
    range_val = df[col].max() - df[col].min()

    mode_str = ', '.join(map(str, mode_list)) if mode_list else 'No mode'

    stats_df.loc[col] = [mean, median, mode_str, variance, std_dev, range_val]

print(stats_df)
