import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.geometry import Point

# Load your CSV data
df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

# Create geometry points
geometry = [Point(xy) for xy in zip(df['Longitude'], df['Latitude'])]
gdf = gpd.GeoDataFrame(df, geometry=geometry)

# Load the Natural Earth countries shapefile (update the path!)
world = gpd.read_file(r"C:/Users/karma/Downloads/110m_cultural/ne_110m_admin_0_countries.shp")

# Plot map
fig, ax = plt.subplots(figsize=(15, 10))
world.plot(ax=ax, alpha=0.5, edgecolor='k')
gdf.plot(ax=ax, color='red', markersize=10)
plt.title('Restaurant Locations')
plt.show()
