import pandas as pd
import folium

# Load dataset
df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")
 
# Make sure latitude and longitude columns exist; adjust names if different
lat_col = 'Latitude'   # replace with your actual latitude column name
lon_col = 'Longitude'  # replace with your actual longitude column name

# Drop rows with missing lat/lon to avoid errors
df_map = df.dropna(subset=[lat_col, lon_col])

# Center the map at the mean latitude and longitude
map_center = [df_map[lat_col].mean(), df_map[lon_col].mean()]

# Create map object
mymap = folium.Map(location=map_center, zoom_start=10)

# Add each restaurant as a marker
for idx, row in df_map.iterrows():
    folium.Marker(
        location=[row[lat_col], row[lon_col]],
        popup=row.get('Restaurant Name', 'Restaurant')  # change if you have a name column
    ).add_to(mymap)

# Save the map as an HTML file or display in notebook
mymap.save("C:/Users/karma/OneDrive/Desktop/Internship/restaurant_map.html")


print("Map saved as restaurant_map.html")
