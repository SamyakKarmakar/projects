import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import f_oneway

# Load dataset
df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

# Replace with your actual column names
lat_col = 'Latitude'
lon_col = 'Longitude'
rating_col = 'Aggregate rating'  # or 'Aggregate rating' or whatever your rating column is
city_col = 'City'

# Drop rows with missing values in relevant columns
df_clean = df.dropna(subset=[lat_col, lon_col, rating_col, city_col])

# --- Step 1: Correlation between numeric location and rating ---

corr_lat = df_clean[lat_col].corr(df_clean[rating_col])
corr_lon = df_clean[lon_col].corr(df_clean[rating_col])

print(f"Correlation between Latitude and Rating: {corr_lat:.3f}")
print(f"Correlation between Longitude and Rating: {corr_lon:.3f}")

# --- Step 2: Average rating by city ---

city_rating = df_clean.groupby(city_col)[rating_col].mean().sort_values(ascending=False)
print("\nAverage Rating by City (Top 10):")
print(city_rating.head(10))

print("\nAverage Rating by City (Bottom 10):")
print(city_rating.tail(10))

# Plot average rating for top 10 cities by number of restaurants
top_cities = df_clean[city_col].value_counts().head(10).index
avg_rating_top_cities = df_clean[df_clean[city_col].isin(top_cities)].groupby(city_col)[rating_col].mean()

plt.figure(figsize=(10,5))
avg_rating_top_cities.plot(kind='bar', color='skyblue')
plt.title('Average Restaurant Rating in Top 10 Cities')
plt.ylabel('Average Rating')
plt.xlabel('City')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# --- Step 3: ANOVA test to check if ratings differ significantly across cities ---

# Filter groups with at least 10 restaurants for statistical validity
groups = [group[rating_col].values for name, group in df_clean.groupby(city_col) if len(group) >= 10]

anova_result = f_oneway(*groups)

print(f"\nANOVA test statistic: {anova_result.statistic:.3f}, p-value: {anova_result.pvalue:.5f}")

if anova_result.pvalue < 0.05:
    print("Result: Significant differences in ratings exist across cities.")
else:
    print("Result: No significant difference in ratings across cities.")
