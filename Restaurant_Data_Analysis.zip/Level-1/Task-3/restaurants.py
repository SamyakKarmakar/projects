import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

city_counts = df['City'].value_counts()
print("Number of restaurants per City:")
print(city_counts)

city_percent = (city_counts / city_counts.sum()) * 100
print("\nPercentage distribution of restaurants by City:")
print(city_percent.round(2))

plt.figure(figsize=(12,6))
city_counts.head(10).plot(kind='bar')
plt.title('Top 10 Cities by Number of Restaurants')
plt.xlabel('City')
plt.ylabel('Number of Restaurants')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


country_col = 'Country' if 'Country' in df.columns else 'Country Code'

country_counts = df[country_col].value_counts()
print(f"\nNumber of restaurants per {country_col}:")
print(country_counts)

country_percent = (country_counts / country_counts.sum()) * 100
print(f"\nPercentage distribution of restaurants by {country_col}:")
print(country_percent.round(2))

plt.figure(figsize=(12,6))
country_counts.head(10).plot(kind='bar', color='orange')
plt.title(f'Top 10 {country_col}s by Number of Restaurants')
plt.xlabel(country_col)
plt.ylabel('Number of Restaurants')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
