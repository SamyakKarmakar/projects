import pandas as pd

# Load the dataset
df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")  # Replace with your actual file path

# Get the number of rows and columns
rows, columns = df.shape

# Print the result
print(f"Number of rows: {rows}")
print(f"Number of columns: {columns}")
