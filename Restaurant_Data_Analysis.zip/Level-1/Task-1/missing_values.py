import pandas as pd

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")  

for col in df.columns:
    if df[col].dtype == 'object':  
        df[col] = df[col].fillna(df[col].mode()[0])
    else:  
        df[col] = df[col].fillna(df[col].median())

print("Total remaining missing values:", df.isnull().sum().sum())
