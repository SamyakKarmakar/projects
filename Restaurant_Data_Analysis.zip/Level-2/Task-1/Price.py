import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

price_col = 'Price range'
delivery_col = 'Has Online delivery'

df[delivery_col] = df[delivery_col].str.strip().str.lower()

df = df.dropna(subset=[price_col, delivery_col])

total_by_price = df.groupby(price_col)[delivery_col].count()

delivery_by_price = df[df[delivery_col] == 'yes'].groupby(price_col)[delivery_col].count()

delivery_percent_by_price = (delivery_by_price / total_by_price) * 100

print("Online Delivery Availability by Price Range:")
print(delivery_percent_by_price)

plt.figure(figsize=(8, 5))
delivery_percent_by_price.plot(kind='bar', color='green')
plt.title('Online Delivery Availability by Price Range')
plt.xlabel('Price Range')
plt.ylabel('Percentage with Online Delivery')
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()
