import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

booking_col = 'Has Table booking'
rating_col = 'Aggregate rating' 

df[booking_col] = df[booking_col].str.strip().str.lower()

df = df.dropna(subset=[booking_col, rating_col])

avg_rating_by_booking = df.groupby(booking_col)[rating_col].mean()
print("\nAverage Ratings based on Table Booking Availability:")
print(avg_rating_by_booking)

plt.figure(figsize=(6, 4))
avg_rating_by_booking.plot(kind='bar', color=['skyblue', 'orange'])
plt.title('Average Restaurant Ratings: Table Booking vs. No Table Booking')
plt.ylabel('Average Rating')
plt.xlabel('Table Booking Available')
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()
