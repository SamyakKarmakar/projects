import pandas as pd

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")


print("Table Booking Options:", df['Has Table booking'].unique())
print("Online Delivery Options:", df['Has Online delivery'].unique())

df['Has Table booking'] = df['Has Table booking'].str.strip().str.lower()
df['Has Online delivery'] = df['Has Online delivery'].str.strip().str.lower()

total_restaurants = len(df)

table_booking_count = (df['Has Table booking'] == 'yes').sum()
table_booking_percent = (table_booking_count / total_restaurants) * 100

online_delivery_count = (df['Has Online delivery'] == 'yes').sum()
online_delivery_percent = (online_delivery_count / total_restaurants) * 100

print(f"\nTotal Restaurants: {total_restaurants}")
print(f"Restaurants offering Table Booking: {table_booking_count} ({table_booking_percent:.2f}%)")
print(f"Restaurants offering Online Delivery: {online_delivery_count} ({online_delivery_percent:.2f}%)")
