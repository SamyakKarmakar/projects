import pandas as pd

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

most_common_price_range = df['Price range'].mode()[0]
price_range_counts = df['Price range'].value_counts()

print(f"Most Common Price Range: {most_common_price_range}")
print("\nPrice Range Frequency:")
print(price_range_counts)
