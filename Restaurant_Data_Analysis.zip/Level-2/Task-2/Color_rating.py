import pandas as pd

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")

price_col = 'Price range'
rating_col = 'Aggregate rating'
color_col = 'Rating color'

df = df.dropna(subset=[price_col, rating_col, color_col])

grouped = df.groupby([price_col, color_col])[rating_col].mean().reset_index()

top_row = grouped.loc[grouped[rating_col].idxmax()]

print("Color representing the highest average rating among price ranges:")
print(f"Price Range: {top_row[price_col]}")
print(f"Rating Color: {top_row[color_col]}")
print(f"Average Rating: {top_row[rating_col]:.2f}")
