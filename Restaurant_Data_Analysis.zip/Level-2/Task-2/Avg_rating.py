import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:/Users/karma/OneDrive/Desktop/Internship/Dataset .csv")


price_col = 'Price range'
rating_col = 'Aggregate rating'

df = df.dropna(subset=[price_col, rating_col])

avg_rating_by_price = df.groupby(price_col)[rating_col].mean().sort_index()

print("Average Aggregate Rating by Price Range:")
print(avg_rating_by_price)

plt.figure(figsize=(7, 4))
avg_rating_by_price.plot(kind='bar', color='royalblue')
plt.title('Average Aggregate Rating by Price Range')
plt.xlabel('Price Range')
plt.ylabel('Average Aggregate Rating')
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()
